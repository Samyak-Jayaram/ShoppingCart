
public class ShoppingCart
{
    public static void main (String args[]) 
    {
        new Gui();  
    }
    
}